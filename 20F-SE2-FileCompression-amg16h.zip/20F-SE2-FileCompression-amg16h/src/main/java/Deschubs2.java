/*************************************************************************
 *  Author:       amg16h Adam Garcia
 *  Course:       CS375 Software Engineering II
 *  Date:         Fall 2020
 * 
 *  Program:      Deschubs
 *  Compile:      javac Deschubs.java
 *  Execute:      java -cp target/classes Deschubs.java
 *  Dependencies: BinaryIn.java BinaryOut.java
 * 
 *
 *************************************************************************/


public class Deschubs {

    // LZW
    private static final int R = 256;        // number of input chars
    private static final int L = 4096;       // number of codewords = 2^W
    private static final int W = 12;   

    ///////////////////////////////////////////////

    // alphabet size of extended ASCII
    public static boolean logging = true;

    // Huffman trie node
    private static class Node implements Comparable<Node> {
        private final char ch;
        private final int freq;
        private final Node left, right;

        Node(char ch, int freq, Node left, Node right) {
            this.ch    = ch;
            this.freq  = freq;
            this.left  = left;
            this.right = right;
        }

        // is the node a leaf node?
        private boolean isLeaf() {
            assert (left == null && right == null) || (left != null && right != null);
            return (left == null && right == null);
        }

        // compare, based on frequency
        public int compareTo(Node that) {
            return this.freq - that.freq;
        }
    }


    public static void err_print(String msg)
    {
	if (logging)
	    System.err.print(msg);
    }

    public static void err_println(String msg)
    {
	if (logging)
	    {
		System.err.println(msg);
	    }
    }

    public static void expandL(BinaryIn in, BinaryOut out) {
        String[] st = new String[L];
        int i; // next available codeword value

        // initialize symbol table with all 1-character strings
        for (i = 0; i < R; i++)
            st[i] = "" + (char) i;
        st[i++] = "";  // (unused) lookahead for EOF

        int codeword = in.readInt(W);
        String val = st[codeword];

        while (true) {
            out.write(val);
            codeword = in.readInt(W);
            if (codeword == R) break;
            String s = st[codeword];
            if (i == codeword) s = val + val.charAt(0);  // special case hack
            if (i < L) st[i++] = val + s.charAt(0);
            val = s;
        }
        out.close();
    }


    // expand Huffman-encoded input from standard input and write to standard output
    public static void expandH(BinaryIn in, BinaryOut out) {

        // read in Huffman trie from input stream
        Node root = readTrie(in); 

        // number of bytes to write
        int length = in.readInt();

        // decode using the Huffman trie
        for (int i = 0; i < length; i++) {
            Node x = root;
            while (!x.isLeaf()) {
                boolean bit = in.readBoolean();
                if (bit) x = x.right;
                else     x = x.left;
            }
            out.write(x.ch);
        }
        out.flush();
    }

    private static Node readTrie(BinaryIn in) {
        boolean isLeaf = in.readBoolean();
        if (isLeaf) {
	    char x = in.readChar();
	    err_println("t: " + x );
            return new Node(x, -1, null, null);
        }
        else {
	    err_print("f");
            return new Node('\0', -1, readTrie(in), readTrie(in));
        }
    }




    public static void untars(String args) {
        BinaryIn in = new BinaryIn(args);
        BinaryOut out = null;
        char sep =  (char) 255;  // all ones 11111111

        // continure reading from archive until empty
        while (!in.isEmpty()) {
            try {
                // get individual archived file filename
                int filenamesize = in.readInt();
	            sep = in.readChar();
	            String filename="";
	            for (int i=0; i<filenamesize; i++) {
	                // concatenate characters to string
                    filename = filename + in.readChar();
                }

                // get individual archived file content
	            sep = in.readChar();
	            long filesize = in.readLong();
	            sep = in.readChar();
	            System.out.println("Extracting file: " + filename + " ("+ filesize +").");
	            out = new BinaryOut(filename);
	            for (int i=0; i<filesize; i++){
                    // copy input to output
                    out.write(in.readChar());
                }
                out.close();
	        } finally {
	            if (out != null)
	    	    out.close();
            }    
        } 
    }



    public static void main(String[] args) {

        BinaryIn in = null;
        BinaryOut out = null;
        
        String filename = "";
        String filetype = "";

        if (args.length < 1) {
            System.out.println("Wong number of arguments. At least one input is required.");
        }

        for (int i = 0; i < args.length; i++) {


            //check if file actally exists
            try {
                if (){

                    }
                
            } catch (Exception e) {
                return;
            }
                // if it doesnt exist output that it doesnt exist and move on


            // gets filename excluding filetype
            for (int j = 0; j < args[i].length()-3; j++) {
                filename = filename + args[i].charAt(j);
            }

            // gets 3 char that are filetype
            for (int j = args[i].length()-3; j < args[i].length(); j++) {
                filetype = filetype + args[i].charAt(j);
            }

            try {
                in = new BinaryIn(args[i]);
                out = new BinaryOut(filename);

                System.out.println("filename: " + filename);
                System.out.println("filetype: " + filetype);

                // determines which file uncompression to run
                if (filetype.equals(".zh")) {
                    // expand with huffman
                    expandH(in, out);
                    // untars archive
                    untars(filename);
                }
                else if (filetype.equals(".ll")) {
                    expandL(in, out);
                }
                else if (filetype.equals(".hh")) {
                    expandH(in, out);
                }
                else {
                    System.out.println("incorect filetype input");
                }
            } finally {
                if (out != null);
                    out.close();
            }

            // reset strings
            filename = "";
            filetype = "";
        }
    }
}