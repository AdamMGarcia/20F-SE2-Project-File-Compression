/************************************************************************************************
 *  Author:       amg16h Adam Garcia
 *  Course:       CS375 Software Engineering II
 *  Date:         Fall 2020
 *
 *  Program:      SchubsArc
 *  Compile:      javac SchubsArc.java
 *  Execute:      java -cp target/classes SchubsArc.java
 *  Dependencies: BinaryIn.java BinaryOut.java
 *  
 *  Note:         SchubsArc.java will archive all the files contained in the given archive
 * 			 	  then the archived will be compressed using Huffman
 * 
 * 			      The fllowing classes were desgined by Robert Sedgewick and Kevin Wayne:
 * 			      BinaryDump.java BinaryIn.java BinaryOut.java BinaryStdIn.java 
 * 			      BinaryStdOut.java StdIn.java StdOut.java
 * 
 * 			      To view archive contents in terminal run:
 * 				     Compile: javac BinaryDump.java
 * 				     Execute: java -cp target/classes BinaryDump 16 < <archiveFileName>
 *
************************************************************************************************/

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.*;

public class SchubsArc {
    public static char separator = (char) 255;  // all ones 11111111
	private static Boolean inputFileExists = true;
	private static Boolean inputCorrect = true;
	public static Boolean inputFileExists() {return inputFileExists;}
    public static Boolean correctInput() {return inputCorrect;}
	public static BinaryOut out = null;


    public static void main(String[] args) {
		// input must be one archive and one or more filenames
		if(args.length <= 1) {
			System.out.println("Incorrect number of filenames. At least one archive and one file are required.");
			inputCorrect = false;
			return;
		}

		File archiveFile = null;
		String archiveFileName = args[0] + ".zh";

		// TARS archives files
		try {
            // get archive file
            archiveFile = new File(archiveFileName);

            // deletes existing archive file and creates new one
			if (archiveFile.exists())
				archiveFile.delete();
			archiveFile.createNewFile();

            // define binary out
            out = new BinaryOut(archiveFileName);
            System.out.println("set Binary OUT");

            // archive all inputed files
            for (int i = 1; i < args.length; i++) {
				
                archiveTheInputFile(archiveFileName, args[i]);
				System.out.println("File: "+ i);

				// if an inputed file fails
				if (!inputFileExists()) {
					System.out.println("The file: " + args[i] + " does not exist");
					return;
				}
			}
			
			// closes output to archive
            if (out != null)
                out.close();
			System.out.println("closed OUT");

		// if something breaks
		} catch (Exception e) {
			System.out.println("Could not archive the input files.");
		}

		// HUFFMAN Compress with .zh
		String[] huffCompress = {archiveFileName};
		SchubsH schubsH = new SchubsH();
		schubsH.main(huffCompress);
		// delete temp archive file
	}

    
    // archives inputed file into inputed archive
    private static void archiveTheInputFile(String archiveFile, String fileName) throws IOException{
        //BinaryOut out = null;
        BinaryIn binaryInput = null;
        
        File fileToArchive = new File(fileName);

        // check that input file is valid
        if (!fileToArchive.exists() || !fileToArchive.isFile()) {
			System.out.println("The input file was invalid");
			inputFileExists = false;
			return;
		}
			
		// first file
		long filesize = fileToArchive.length();
		int filenamesize = fileName.length();
		
		out.write(filenamesize); // 4 bytes (32 bits)
		out.write(separator); // 1 byte (8 bits)
		out.write(fileName); //  
		out.write(separator); // 1 byte (8 bits)
		out.write(filesize); // 8 bytes (64 bits)
		out.write(separator); // 1 byte (8 bits)

        // copies everything in file to archive
		binaryInput = new BinaryIn(fileName);
		while (!binaryInput.isEmpty()) {
            out.write(binaryInput.readChar());
            System.out.println("ReadChar");
		}
    }
}